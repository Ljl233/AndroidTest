package com.example.recyclerviewtest;

import java.util.Date;

public class Data {

    int num;

    Data(int num) {
        this.num = num;
    }

    int getNum() {
        return num;
    }

    void setNum(int num) {
        this.num = num;
    }


}
