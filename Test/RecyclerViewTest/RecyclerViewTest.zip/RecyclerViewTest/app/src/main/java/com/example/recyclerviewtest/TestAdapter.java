package com.example.recyclerviewtest;

import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.zip.Inflater;

public class TestAdapter extends RecyclerView.Adapter<TestAdapter.MyViewHolder> {

    //自定义ViewHolder
    public class MyViewHolder extends RecyclerView.ViewHolder {
        View itemView;
        TextView textView;
        ImageView imageView;

        public MyViewHolder(@NonNull View view) {
            super(view);
            itemView = view;
            textView = view.findViewById(R.id.item_tv);
            imageView = view.findViewById(R.id.item_iv);

        }
    }

    private List<Data> datas;

    //构造器
    public TestAdapter(List<Data> datas) {
        this.datas = datas;
    }

    //将item封装为一个ViewHolder
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.rc_item, parent, false);
        return new MyViewHolder(view);
    }

    //适配渲染数据到View中
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.imageView.setImageResource(R.drawable.ic_launcher_background);
        holder.textView.setText(position);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "onclick!!!" + position, Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

}
